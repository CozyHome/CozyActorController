using UnityEngine;
using com.cozyhome.Singleton;
namespace com.cozyhome.Systems { public partial class SystemsInjector : SingletonBehaviour<SystemsInjector> { } }

